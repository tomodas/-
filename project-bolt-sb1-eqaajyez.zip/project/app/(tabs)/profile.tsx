import { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, TextInput, ScrollView, useColorScheme } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { CreditCard as Edit2, SquareCheck as CheckSquare, LogOut } from 'lucide-react-native';

export default function ProfileScreen() {
  const [isEditing, setIsEditing] = useState(false);
  const [username, setUsername] = useState('ジャングルマスター');
  const [avatar, setAvatar] = useState('https://images.pexels.com/photos/247431/pexels-photo-247431.jpeg?auto=compress&cs=tinysrgb&w=400');
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const stats = {
    totalGames: 42,
    wins: 24,
    losses: 15,
    draws: 3,
    winRate: '57%',
    favoriteHand: 'グー',
  };

  const toggleEdit = () => {
    setIsEditing(!isEditing);
  };

  return (
    <SafeAreaView style={[styles.container, isDark && styles.containerDark]}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.profileHeader}>
          <View style={styles.avatarContainer}>
            <Image source={{ uri: avatar }} style={styles.avatar} />
            {isEditing && (
              <TouchableOpacity style={styles.editAvatarButton}>
                <Text style={styles.editAvatarText}>変更</Text>
              </TouchableOpacity>
            )}
          </View>
          
          <View style={styles.nameContainer}>
            {isEditing ? (
              <TextInput
                style={[styles.nameInput, isDark && styles.nameInputDark]}
                value={username}
                onChangeText={setUsername}
                maxLength={15}
              />
            ) : (
              <Text style={[styles.username, isDark && styles.usernameDark]}>{username}</Text>
            )}
            
            <TouchableOpacity 
              style={styles.editButton} 
              onPress={toggleEdit}
            >
              {isEditing ? (
                <CheckSquare color={isDark ? '#5CBF3A' : '#47A025'} size={20} />
              ) : (
                <Edit2 color={isDark ? '#5CBF3A' : '#47A025'} size={20} />
              )}
            </TouchableOpacity>
          </View>
        </View>
        
        <View style={[styles.statsCard, isDark && styles.statsCardDark]}>
          <Text style={[styles.sectionTitle, isDark && styles.sectionTitleDark]}>ゲーム統計</Text>
          
          <View style={styles.statsGrid}>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, isDark && styles.statValueDark]}>{stats.totalGames}</Text>
              <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>総ゲーム数</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, styles.winValue]}>{stats.wins}</Text>
              <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>勝利</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, styles.lossValue]}>{stats.losses}</Text>
              <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>敗北</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, styles.drawValue]}>{stats.draws}</Text>
              <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>引き分け</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, isDark && styles.statValueDark]}>{stats.winRate}</Text>
              <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>勝率</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={[styles.statValue, isDark && styles.statValueDark]}>{stats.favoriteHand}</Text>
              <Text style={[styles.statLabel, isDark && styles.statLabelDark]}>よく使う手</Text>
            </View>
          </View>
        </View>
        
        <View style={[styles.achievementsCard, isDark && styles.achievementsCardDark]}>
          <Text style={[styles.sectionTitle, isDark && styles.sectionTitleDark]}>実績</Text>
          
          <View style={styles.achievementsList}>
            <View style={[styles.achievementItem, isDark && styles.achievementItemDark]}>
              <View style={[styles.achievementBadge, styles.achievementUnlocked]}>
                <Text style={styles.achievementBadgeText}>✓</Text>
              </View>
              <View>
                <Text style={[styles.achievementName, isDark && styles.achievementNameDark]}>初勝利</Text>
                <Text style={[styles.achievementDesc, isDark && styles.achievementDescDark]}>初めての勝利を獲得する</Text>
              </View>
            </View>
            
            <View style={[styles.achievementItem, isDark && styles.achievementItemDark]}>
              <View style={[styles.achievementBadge, styles.achievementUnlocked]}>
                <Text style={styles.achievementBadgeText}>✓</Text>
              </View>
              <View>
                <Text style={[styles.achievementName, isDark && styles.achievementNameDark]}>ジャングルの王者</Text>
                <Text style={[styles.achievementDesc, isDark && styles.achievementDescDark]}>10勝達成</Text>
              </View>
            </View>
            
            <View style={[styles.achievementItem, isDark && styles.achievementItemDark]}>
              <View style={[styles.achievementBadge, styles.achievementLocked]}>
                <Text style={styles.achievementBadgeText}>?</Text>
              </View>
              <View>
                <Text style={[styles.achievementName, isDark && styles.achievementNameDark]}>無敗の王者</Text>
                <Text style={[styles.achievementDesc, isDark && styles.achievementDescDark]}>5連勝を達成する</Text>
              </View>
            </View>
          </View>
        </View>
        
        <TouchableOpacity style={styles.logoutButton}>
          <LogOut size={18} color="#FFFFFF" />
          <Text style={styles.logoutText}>ログアウト</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  scrollContent: {
    padding: 20,
  },
  profileHeader: {
    alignItems: 'center',
    marginBottom: 30,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 15,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: '#47A025',
  },
  editAvatarButton: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#47A025',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 15,
  },
  editAvatarText: {
    color: 'white',
    fontSize: 12,
    fontFamily: 'Noto-Sans-JP-Medium',
  },
  nameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  username: {
    fontSize: 22,
    fontFamily: 'Noto-Sans-JP-Bold',
    color: '#333',
    marginRight: 10,
  },
  usernameDark: {
    color: '#E0E0E0',
  },
  nameInput: {
    fontSize: 22,
    fontFamily: 'Noto-Sans-JP-Bold',
    color: '#333',
    borderBottomWidth: 2,
    borderBottomColor: '#47A025',
    paddingBottom: 2,
    marginRight: 10,
    textAlign: 'center',
  },
  nameInputDark: {
    color: '#E0E0E0',
  },
  editButton: {
    padding: 5,
  },
  statsCard: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statsCardDark: {
    backgroundColor: '#2A2A2A',
  },
  sectionTitle: {
    fontSize: 18,
    fontFamily: 'Noto-Sans-JP-Bold',
    color: '#333',
    marginBottom: 15,
  },
  sectionTitleDark: {
    color: '#E0E0E0',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  statItem: {
    width: '30%',
    alignItems: 'center',
    marginBottom: 15,
  },
  statValue: {
    fontSize: 20,
    fontFamily: 'Noto-Sans-JP-Bold',
    color: '#333',
    marginBottom: 5,
  },
  statValueDark: {
    color: '#E0E0E0',
  },
  winValue: {
    color: '#47A025',
  },
  lossValue: {
    color: '#E74C3C',
  },
  drawValue: {
    color: '#3498DB',
  },
  statLabel: {
    fontSize: 12,
    fontFamily: 'Noto-Sans-JP-Regular',
    color: '#666',
  },
  statLabelDark: {
    color: '#AAAAAA',
  },
  achievementsCard: {
    backgroundColor: 'white',
    borderRadius: 15,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  achievementsCardDark: {
    backgroundColor: '#2A2A2A',
  },
  achievementsList: {
    gap: 15,
  },
  achievementItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 10,
    padding: 15,
  },
  achievementItemDark: {
    backgroundColor: '#333333',
  },
  achievementBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 15,
  },
  achievementUnlocked: {
    backgroundColor: '#47A025',
  },
  achievementLocked: {
    backgroundColor: '#AAAAAA',
  },
  achievementBadgeText: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
  achievementName: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 16,
    color: '#333',
    marginBottom: 3,
  },
  achievementNameDark: {
    color: '#E0E0E0',
  },
  achievementDesc: {
    fontFamily: 'Noto-Sans-JP-Regular',
    fontSize: 12,
    color: '#666',
  },
  achievementDescDark: {
    color: '#AAAAAA',
  },
  logoutButton: {
    backgroundColor: '#E74C3C',
    padding: 15,
    borderRadius: 10,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  logoutText: {
    color: 'white',
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 16,
    marginLeft: 10,
  },
});