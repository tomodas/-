import { useState } from 'react';
import { View, Text, StyleSheet, FlatList, Image, TouchableOpacity, useColorScheme } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronDown, ChevronUp, Medal } from 'lucide-react-native';

// Mock leaderboard data
const MOCK_LEADERBOARD = [
  { id: '1', username: 'ジャングルキング', wins: 152, losses: 43, winRate: '77.9%', rank: 1, avatar: 'https://images.pexels.com/photos/1454786/pexels-photo-1454786.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '2', username: 'パンダマスター', wins: 147, losses: 50, winRate: '74.6%', rank: 2, avatar: 'https://images.pexels.com/photos/3777622/pexels-photo-3777622.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '3', username: 'モンキーパワー', wins: 135, losses: 48, winRate: '73.8%', rank: 3, avatar: 'https://images.pexels.com/photos/3751397/pexels-photo-3751397.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '4', username: 'タイガーハンド', wins: 120, losses: 52, winRate: '69.8%', rank: 4, avatar: 'https://images.pexels.com/photos/2649841/pexels-photo-2649841.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '5', username: 'エレファントパワー', wins: 110, losses: 49, winRate: '69.2%', rank: 5, avatar: 'https://images.pexels.com/photos/3832684/pexels-photo-3832684.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '6', username: 'ライオンキング', wins: 105, losses: 50, winRate: '67.7%', rank: 6, avatar: 'https://images.pexels.com/photos/33045/lion-wild-africa-african.jpg?auto=compress&cs=tinysrgb&w=400' },
  { id: '7', username: 'コアラドリーム', wins: 98, losses: 47, winRate: '67.6%', rank: 7, avatar: 'https://images.pexels.com/photos/3690509/pexels-photo-3690509.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '8', username: 'パロットマスター', wins: 95, losses: 46, winRate: '67.4%', rank: 8, avatar: 'https://images.pexels.com/photos/1661179/pexels-photo-1661179.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '9', username: 'ジャングルマスター', wins: 90, losses: 45, winRate: '66.7%', rank: 9, avatar: 'https://images.pexels.com/photos/247431/pexels-photo-247431.jpeg?auto=compress&cs=tinysrgb&w=400' },
  { id: '10', username: 'クロコダイル', wins: 85, losses: 43, winRate: '66.4%', rank: 10, avatar: 'https://images.pexels.com/photos/17797636/pexels-photo-17797636/free-photo-of-close-up-shot-of-a-nile-crocodile.jpeg?auto=compress&cs=tinysrgb&w=400' },
];

type SortKey = 'rank' | 'winRate';

export default function LeaderboardScreen() {
  const [sortBy, setSortBy] = useState<SortKey>('rank');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  
  const handleSort = (key: SortKey) => {
    if (sortBy === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(key);
      setSortOrder('asc');
    }
  };
  
  const sortedData = [...MOCK_LEADERBOARD].sort((a, b) => {
    let compareA, compareB;
    
    if (sortBy === 'rank') {
      compareA = a.rank;
      compareB = b.rank;
    } else if (sortBy === 'winRate') {
      compareA = parseFloat(a.winRate);
      compareB = parseFloat(b.winRate);
    }
    
    if (sortOrder === 'asc') {
      return compareA - compareB;
    } else {
      return compareB - compareA;
    }
  });
  
  const renderRankBadge = (rank: number) => {
    if (rank === 1) {
      return <Medal color="#FFD700\" size={24} />;
    } else if (rank === 2) {
      return <Medal color="#C0C0C0" size={24} />;
    } else if (rank === 3) {
      return <Medal color="#CD7F32\" size={24} />;
    } else {
      return <Text style={styles.rankText}>{rank}</Text>;
    }
  };

  return (
    <SafeAreaView style={[styles.container, isDark && styles.containerDark]}>
      <View style={[styles.headerContainer, isDark && styles.headerContainerDark]}>
        <Text style={[styles.headerTitle, isDark && styles.headerTitleDark]}>トッププレイヤー</Text>
        <Text style={[styles.headerSubtitle, isDark && styles.headerSubtitleDark]}>
          ジャングルの強者たち
        </Text>
      </View>
      
      <View style={[styles.tableHeader, isDark && styles.tableHeaderDark]}>
        <TouchableOpacity style={styles.rankHeader} onPress={() => handleSort('rank')}>
          <Text style={[styles.headerText, isDark && styles.headerTextDark]}>順位</Text>
          {sortBy === 'rank' && (
            sortOrder === 'asc' ? <ChevronDown size={16} color={isDark ? '#AAAAAA' : '#666'} /> 
                                : <ChevronUp size={16} color={isDark ? '#AAAAAA' : '#666'} />
          )}
        </TouchableOpacity>
        
        <Text style={[styles.headerText, styles.playerHeader, isDark && styles.headerTextDark]}>プレイヤー</Text>
        
        <TouchableOpacity style={styles.winRateHeader} onPress={() => handleSort('winRate')}>
          <Text style={[styles.headerText, isDark && styles.headerTextDark]}>勝率</Text>
          {sortBy === 'winRate' && (
            sortOrder === 'asc' ? <ChevronDown size={16} color={isDark ? '#AAAAAA' : '#666'} /> 
                                : <ChevronUp size={16} color={isDark ? '#AAAAAA' : '#666'} />
          )}
        </TouchableOpacity>
      </View>
      
      <FlatList
        data={sortedData}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={[styles.leaderboardItem, isDark && styles.leaderboardItemDark]}>
            <View style={styles.rankContainer}>
              {renderRankBadge(item.rank)}
            </View>
            
            <View style={styles.playerInfo}>
              <Image source={{ uri: item.avatar }} style={styles.avatar} />
              <Text style={[styles.username, isDark && styles.usernameDark]}>
                {item.username}
              </Text>
            </View>
            
            <View style={styles.statsContainer}>
              <Text style={[styles.winRate, isDark && styles.winRateDark]}>{item.winRate}</Text>
              <Text style={[styles.winsLosses, isDark && styles.winsLossesDark]}>
                {item.wins}勝{item.losses}敗
              </Text>
            </View>
          </View>
        )}
        contentContainerStyle={styles.list}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  headerContainer: {
    padding: 20,
    backgroundColor: '#47A025',
  },
  headerContainerDark: {
    backgroundColor: '#2D6A17',
  },
  headerTitle: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 24,
    color: 'white',
    marginBottom: 5,
  },
  headerTitleDark: {
    color: 'white',
  },
  headerSubtitle: {
    fontFamily: 'Noto-Sans-JP-Regular',
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.8)',
  },
  headerSubtitleDark: {
    color: 'rgba(255, 255, 255, 0.8)',
  },
  tableHeader: {
    flexDirection: 'row',
    paddingHorizontal: 15,
    paddingVertical: 12,
    backgroundColor: '#F0F0F0',
    borderBottomWidth: 1,
    borderBottomColor: '#DDDDDD',
  },
  tableHeaderDark: {
    backgroundColor: '#2A2A2A',
    borderBottomColor: '#333333',
  },
  headerText: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 14,
    color: '#666',
  },
  headerTextDark: {
    color: '#AAAAAA',
  },
  rankHeader: {
    width: '20%',
    flexDirection: 'row',
    alignItems: 'center',
  },
  playerHeader: {
    width: '50%',
  },
  winRateHeader: {
    width: '30%',
    flexDirection: 'row',
    alignItems: 'center',
  },
  list: {
    padding: 10,
  },
  leaderboardItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 15,
    backgroundColor: 'white',
    borderRadius: 10,
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  leaderboardItemDark: {
    backgroundColor: '#2A2A2A',
  },
  rankContainer: {
    width: '15%',
    alignItems: 'center',
    justifyContent: 'center',
  },
  rankText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 18,
    color: '#666',
  },
  playerInfo: {
    width: '55%',
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    marginRight: 10,
  },
  username: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 16,
    color: '#333',
  },
  usernameDark: {
    color: '#E0E0E0',
  },
  statsContainer: {
    width: '30%',
    alignItems: 'flex-end',
  },
  winRate: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 16,
    color: '#47A025',
    marginBottom: 2,
  },
  winRateDark: {
    color: '#5CBF3A',
  },
  winsLosses: {
    fontFamily: 'Noto-Sans-JP-Regular',
    fontSize: 12,
    color: '#666',
  },
  winsLossesDark: {
    color: '#AAAAAA',
  },
});