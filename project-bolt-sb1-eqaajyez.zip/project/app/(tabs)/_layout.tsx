import { Tabs } from 'expo-router';
import { useColorScheme } from 'react-native';
import { House, Gamepad2, User, Trophy } from 'lucide-react-native';

export default function TabLayout() {
  const colorScheme = useColorScheme();

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#47A025',
        tabBarInactiveTintColor: colorScheme === 'dark' ? '#888888' : '#666666',
        tabBarStyle: {
          backgroundColor: colorScheme === 'dark' ? '#1A1A1A' : '#FFFFFF',
          borderTopColor: colorScheme === 'dark' ? '#333333' : '#E5E5E5',
        },
        tabBarLabelStyle: {
          fontFamily: 'Noto-Sans-JP-Medium',
          fontSize: 12,
        },
        headerStyle: {
          backgroundColor: colorScheme === 'dark' ? '#1A1A1A' : '#FFFFFF',
        },
        headerTitleStyle: {
          fontFamily: 'Noto-Sans-JP-Bold',
          fontSize: 18,
        },
        headerTintColor: colorScheme === 'dark' ? '#FFFFFF' : '#000000',
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'ホーム',
          tabBarIcon: ({ color, size }) => <House color={color} size={size} />,
          headerTitle: 'ジャングル・じゃんけん',
        }}
      />
      <Tabs.Screen
        name="game"
        options={{
          title: 'ゲーム',
          tabBarIcon: ({ color, size }) => <Gamepad2 color={color} size={size} />,
          headerTitle: 'ゲーム',
        }}
      />
      <Tabs.Screen
        name="leaderboard"
        options={{
          title: 'ランキング',
          tabBarIcon: ({ color, size }) => <Trophy color={color} size={size} />,
          headerTitle: 'ランキング',
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'プロフィール',
          tabBarIcon: ({ color, size }) => <User color={color} size={size} />,
          headerTitle: 'プロフィール',
        }}
      />
    </Tabs>
  );
}