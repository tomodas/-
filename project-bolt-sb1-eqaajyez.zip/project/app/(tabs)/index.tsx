import { View, Text, StyleSheet, Image, TouchableOpacity, useColorScheme } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

export default function HomeScreen() {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  const handlePlayNow = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    router.push('/game');
  };

  return (
    <SafeAreaView style={[styles.container, isDark && styles.containerDark]}>
      <LinearGradient
        colors={['rgba(71, 160, 37, 0.1)', 'rgba(71, 160, 37, 0)']}
        style={styles.gradient}
      />
      
      <View style={styles.logoContainer}>
        <Image
          source={{ uri: 'https://images.pexels.com/photos/3789871/pexels-photo-3789871.jpeg?auto=compress&cs=tinysrgb&w=400' }}
          style={styles.logoBackground}
        />
        <View style={styles.logoOverlay}>
          <Text style={[styles.logoText, isDark && styles.logoTextDark]}>
            ジャングル・じゃんけん
          </Text>
          <Text style={[styles.subtitle, isDark && styles.subtitleDark]}>
            Jungle Janken
          </Text>
        </View>
      </View>
      
      <View style={styles.infoContainer}>
        <Text style={[styles.description, isDark && styles.descriptionDark]}>
          ジャングルの奥深くで繰り広げられる、アニマルたちの熱いじゃんけんバトル！
        </Text>
        <Text style={[styles.instructions, isDark && styles.instructionsDark]}>
          グー・チョキ・パーのカードを選び、対戦相手に勝利しよう！
        </Text>
      </View>
      
      <TouchableOpacity 
        style={styles.playButton}
        onPress={handlePlayNow}
        activeOpacity={0.8}
      >
        <LinearGradient
          colors={['#5CBF3A', '#47A025']}
          style={styles.buttonGradient}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
        >
          <Text style={styles.playButtonText}>今すぐプレイ</Text>
        </LinearGradient>
      </TouchableOpacity>

      <View style={styles.featuresContainer}>
        <View style={[styles.featureItem, isDark && styles.featureItemDark]}>
          <Text style={[styles.featureTitle, isDark && styles.featureTitleDark]}>オンライン対戦</Text>
          <Text style={[styles.featureText, isDark && styles.featureTextDark]}>世界中のプレイヤーと対戦できる</Text>
        </View>
        <View style={[styles.featureItem, isDark && styles.featureItemDark]}>
          <Text style={[styles.featureTitle, isDark && styles.featureTitleDark]}>ジャングルテーマ</Text>
          <Text style={[styles.featureText, isDark && styles.featureTextDark]}>美しいジャングルの世界を体験</Text>
        </View>
        <View style={[styles.featureItem, isDark && styles.featureItemDark]}>
          <Text style={[styles.featureTitle, isDark && styles.featureTitleDark]}>シンプルルール</Text>
          <Text style={[styles.featureText, isDark && styles.featureTextDark]}>誰でも簡単に楽しめる</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  gradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 300,
  },
  logoContainer: {
    alignItems: 'center',
    marginTop: 40,
    marginBottom: 30,
  },
  logoBackground: {
    width: 180,
    height: 180,
    borderRadius: 90,
  },
  logoOverlay: {
    position: 'absolute',
    bottom: -30,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 30,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  logoText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 24,
    color: '#47A025',
    marginBottom: 5,
  },
  logoTextDark: {
    color: '#5CBF3A',
  },
  subtitle: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 16,
    color: '#666666',
  },
  subtitleDark: {
    color: '#888888',
  },
  infoContainer: {
    paddingHorizontal: 20,
    marginBottom: 30,
    alignItems: 'center',
  },
  description: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 16,
    color: '#333333',
    textAlign: 'center',
    marginBottom: 15,
  },
  descriptionDark: {
    color: '#E0E0E0',
  },
  instructions: {
    fontFamily: 'Noto-Sans-JP-Regular',
    fontSize: 14,
    color: '#666666',
    textAlign: 'center',
  },
  instructionsDark: {
    color: '#AAAAAA',
  },
  playButton: {
    marginHorizontal: 40,
    borderRadius: 30,
    marginBottom: 40,
    shadowColor: '#47A025',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  buttonGradient: {
    paddingVertical: 16,
    borderRadius: 30,
    alignItems: 'center',
  },
  playButtonText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 18,
    color: 'white',
  },
  featuresContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingHorizontal: 20,
    flexWrap: 'wrap',
  },
  featureItem: {
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    width: '30%',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
    marginBottom: 10,
  },
  featureItemDark: {
    backgroundColor: '#2A2A2A',
  },
  featureTitle: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 12,
    color: '#47A025',
    marginBottom: 5,
    textAlign: 'center',
  },
  featureTitleDark: {
    color: '#5CBF3A',
  },
  featureText: {
    fontFamily: 'Noto-Sans-JP-Regular',
    fontSize: 10,
    color: '#666666',
    textAlign: 'center',
  },
  featureTextDark: {
    color: '#AAAAAA',
  },
});