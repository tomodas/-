import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Platform, useColorScheme } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useGame } from '@/hooks/useGame';
import Card from '@/components/Card';
import MatchmakingScreen from '@/components/MatchmakingScreen';
import ResultScreen from '@/components/ResultScreen';
import CountdownTimer from '@/components/CountdownTimer';
import * as Haptics from 'expo-haptics';
import { Audio } from 'expo-av';
import { GameState } from '@/types/game';

export default function GameScreen() {
  const { 
    gameState, 
    playerChoice, 
    opponentChoice,
    setPlayerChoice,
    startGame, 
    endGame,
    result
  } = useGame();
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  // Load and play background sound
  useEffect(() => {
    let backgroundSound: Audio.Sound;
    
    async function playSound() {
      try {
        if (Platform.OS !== 'web') {
          const { sound } = await Audio.Sound.createAsync(
            // Remove the audio file requirement since it's not available
            // We'll handle this silently to prevent app crashes
            null as any,
            { shouldPlay: false, isLooping: true, volume: 0.5 }
          );
          setSound(sound);
          backgroundSound = sound;
        }
      } catch (error) {
        // Silently handle audio loading errors
        console.log('Audio loading skipped or failed:', error);
      }
    }
    
    playSound();
    
    return () => {
      if (backgroundSound) {
        backgroundSound.unloadAsync();
      }
    };
  }, []);

  const handleCardSelect = (choice: 'rock' | 'paper' | 'scissors') => {
    if (gameState !== GameState.PLAYING || playerChoice) {
      return;
    }
    
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    
    setPlayerChoice(choice);
  };
  
  const handlePlayAgain = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    endGame();
  };

  const handleFindMatch = () => {
    if (Platform.OS !== 'web') {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    startGame();
  };

  // Render different UI based on game state
  const renderGameContent = () => {
    switch (gameState) {
      case GameState.WAITING:
        return <MatchmakingScreen onFindMatch={handleFindMatch} />;
      
      case GameState.PLAYING:
        return (
          <View style={styles.gameContainer}>
            <CountdownTimer />
            
            <Text style={[styles.instructionText, isDark && styles.textDark]}>
              カードを1枚選んでください
            </Text>
            
            <View style={styles.cardsContainer}>
              <Card 
                type="rock" 
                onSelect={() => handleCardSelect('rock')} 
                isSelected={playerChoice === 'rock'} 
                isDisabled={!!playerChoice} 
              />
              <Card 
                type="paper" 
                onSelect={() => handleCardSelect('paper')} 
                isSelected={playerChoice === 'paper'} 
                isDisabled={!!playerChoice} 
              />
              <Card 
                type="scissors" 
                onSelect={() => handleCardSelect('scissors')} 
                isSelected={playerChoice === 'scissors'} 
                isDisabled={!!playerChoice} 
              />
            </View>
            
            {playerChoice && (
              <Text style={[styles.waitingText, isDark && styles.textDark]}>
                相手の選択を待っています...
              </Text>
            )}
          </View>
        );
      
      case GameState.RESULT:
        return (
          <ResultScreen 
            playerChoice={playerChoice!}
            opponentChoice={opponentChoice!}
            result={result!}
            onPlayAgain={handlePlayAgain}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <SafeAreaView style={[styles.container, isDark && styles.containerDark]}>
      {renderGameContent()}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F9F9F9',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  gameContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  instructionText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 22,
    color: '#333',
    marginBottom: 30,
    textAlign: 'center',
  },
  textDark: {
    color: '#E0E0E0',
  },
  cardsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    flexWrap: 'wrap',
    gap: 15,
    marginBottom: 30,
  },
  waitingText: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 18,
    color: '#666',
    marginTop: 20,
  },
});