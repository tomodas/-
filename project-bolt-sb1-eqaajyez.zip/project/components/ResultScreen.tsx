import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, useColorScheme } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';
import Card from './Card';
import { GameResult } from '@/types/game';

type ResultScreenProps = {
  playerChoice: 'rock' | 'paper' | 'scissors';
  opponentChoice: 'rock' | 'paper' | 'scissors';
  result: GameResult;
  onPlayAgain: () => void;
};

export default function ResultScreen({ 
  playerChoice, 
  opponentChoice, 
  result, 
  onPlayAgain 
}: ResultScreenProps) {
  const [revealed, setRevealed] = useState(false);
  const [resultVisible, setResultVisible] = useState(false);
  const fadeAnim = useState(new Animated.Value(0))[0];
  const slideAnim = useState(new Animated.Value(50))[0];
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  useEffect(() => {
    // First reveal opponent's card
    setTimeout(() => {
      setRevealed(true);
      if (Platform.OS !== 'web') {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
      
      // Then show the result
      setTimeout(() => {
        setResultVisible(true);
        Animated.parallel([
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
          }),
          Animated.timing(slideAnim, {
            toValue: 0,
            duration: 500,
            useNativeDriver: true,
          }),
        ]).start();
        
        if (Platform.OS !== 'web') {
          Haptics.notificationAsync(
            result === 'win' 
              ? Haptics.NotificationFeedbackType.Success
              : result === 'lose'
                ? Haptics.NotificationFeedbackType.Error
                : Haptics.NotificationFeedbackType.Warning
          );
        }
      }, 1000);
    }, 1000);
  }, []);
  
  const getResultMessage = () => {
    switch (result) {
      case 'win':
        return 'あなたの勝ち！';
      case 'lose':
        return 'あなたの負け...';
      case 'draw':
        return '引き分け';
      default:
        return '';
    }
  };
  
  const getResultColor = () => {
    switch (result) {
      case 'win':
        return ['#47A025', '#5CBF3A'];
      case 'lose':
        return ['#E74C3C', '#F5593D'];
      case 'draw':
        return ['#3498DB', '#4FC3F7'];
      default:
        return ['#666', '#888'];
    }
  };

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <Text style={[styles.versusText, isDark && styles.versusTextDark]}>結果発表</Text>
      
      <View style={styles.cardsContainer}>
        <View style={styles.playerCardContainer}>
          <Text style={[styles.playerLabel, isDark && styles.playerLabelDark]}>あなた</Text>
          <Card 
            type={playerChoice}
            onSelect={() => {}}
            isSelected={true}
            isDisabled={true}
          />
        </View>
        
        <Text style={[styles.vsText, isDark && styles.vsTextDark]}>VS</Text>
        
        <View style={styles.opponentCardContainer}>
          <Text style={[styles.playerLabel, isDark && styles.playerLabelDark]}>相手</Text>
          <Card 
            type={opponentChoice}
            onSelect={() => {}}
            isSelected={true}
            isDisabled={true}
            isOpponent={true}
            isRevealed={revealed}
          />
        </View>
      </View>
      
      {resultVisible && (
        <Animated.View 
          style={[
            styles.resultContainer,
            { 
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            }
          ]}
        >
          <LinearGradient
            colors={getResultColor()}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.resultBanner}
          >
            <Text style={styles.resultText}>{getResultMessage()}</Text>
          </LinearGradient>
          
          <TouchableOpacity 
            style={styles.playAgainButton}
            onPress={onPlayAgain}
            activeOpacity={0.8}
          >
            <Text style={[styles.playAgainText, isDark && styles.playAgainTextDark]}>
              もう一度プレイ
            </Text>
          </TouchableOpacity>
        </Animated.View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#F9F9F9',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  versusText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 24,
    color: '#333',
    marginBottom: 30,
  },
  versusTextDark: {
    color: '#E0E0E0',
  },
  cardsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    width: '100%',
    marginBottom: 50,
  },
  playerCardContainer: {
    alignItems: 'center',
  },
  opponentCardContainer: {
    alignItems: 'center',
  },
  playerLabel: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  playerLabelDark: {
    color: '#AAAAAA',
  },
  vsText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 20,
    color: '#666',
  },
  vsTextDark: {
    color: '#AAAAAA',
  },
  resultContainer: {
    alignItems: 'center',
    width: '100%',
  },
  resultBanner: {
    width: '100%',
    padding: 15,
    borderRadius: 10,
    marginBottom: 30,
    alignItems: 'center',
  },
  resultText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 24,
    color: 'white',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 2,
  },
  playAgainButton: {
    paddingVertical: 15,
    paddingHorizontal: 30,
    backgroundColor: '#F0F0F0',
    borderRadius: 30,
    borderWidth: 2,
    borderColor: '#47A025',
  },
  playAgainText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 16,
    color: '#47A025',
  },
  playAgainTextDark: {
    color: '#5CBF3A',
  },
});