import React, { useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image, Animated, useColorScheme } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

type CardProps = {
  type: 'rock' | 'paper' | 'scissors';
  onSelect: () => void;
  isSelected: boolean;
  isDisabled: boolean;
  isOpponent?: boolean;
  isRevealed?: boolean;
};

const CARD_IMAGES = {
  rock: 'https://images.pexels.com/photos/1851164/pexels-photo-1851164.jpeg?auto=compress&cs=tinysrgb&w=400',
  paper: 'https://images.pexels.com/photos/158651/news-newsletter-newspaper-information-158651.jpeg?auto=compress&cs=tinysrgb&w=400',
  scissors: 'https://images.pexels.com/photos/3990305/pexels-photo-3990305.jpeg?auto=compress&cs=tinysrgb&w=400',
};

const CARD_NAMES = {
  rock: 'グー',
  paper: 'パー',
  scissors: 'チョキ',
};

export default function Card({ type, onSelect, isSelected, isDisabled, isOpponent = false, isRevealed = true }: CardProps) {
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  const scaleAnim = useRef(new Animated.Value(1)).current;
  
  const handlePress = () => {
    if (isDisabled) return;
    
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 0.9,
        duration: 100,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1.05,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
    
    onSelect();
  };
  
  const cardContent = () => {
    if (isOpponent && !isRevealed) {
      return (
        <View style={[styles.cardFront, styles.cardHidden]}>
          <Text style={styles.questionMark}>?</Text>
        </View>
      );
    }
    
    return (
      <View style={styles.cardFront}>
        <Image 
          source={{ uri: CARD_IMAGES[type] }} 
          style={styles.cardImage} 
          resizeMode="cover"
        />
        <LinearGradient
          colors={['transparent', 'rgba(0, 0, 0, 0.7)']}
          style={styles.imageOverlay}
        />
        <Text style={styles.cardName}>{CARD_NAMES[type]}</Text>
      </View>
    );
  };

  return (
    <Animated.View
      style={[
        { transform: [{ scale: scaleAnim }] },
      ]}
    >
      <TouchableOpacity
        activeOpacity={isDisabled ? 1 : 0.8}
        onPress={handlePress}
        style={[
          styles.cardContainer,
          isSelected && styles.selectedCard,
          isDisabled && !isSelected && styles.disabledCard,
          isDark && styles.cardContainerDark,
        ]}
        disabled={isDisabled || isOpponent}
      >
        {cardContent()}
      </TouchableOpacity>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  cardContainer: {
    width: 100,
    height: 150,
    borderRadius: 10,
    overflow: 'hidden',
    marginHorizontal: 5,
    backgroundColor: '#FFFFFF',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  cardContainerDark: {
    backgroundColor: '#2A2A2A',
  },
  selectedCard: {
    borderWidth: 3,
    borderColor: '#47A025',
  },
  disabledCard: {
    opacity: 0.6,
  },
  cardFront: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  cardHidden: {
    backgroundColor: '#47A025',
  },
  cardImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  imageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 50,
  },
  cardName: {
    position: 'absolute',
    bottom: 10,
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 18,
    color: 'white',
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 3,
  },
  questionMark: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 40,
    color: 'white',
  },
});