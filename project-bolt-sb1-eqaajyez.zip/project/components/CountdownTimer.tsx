import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, Animated, Easing, useColorScheme } from 'react-native';
import { useGame } from '@/hooks/useGame';
import { GameState } from '@/types/game';

export default function CountdownTimer() {
  const { gameState, setTimeUp } = useGame();
  const [timeLeft, setTimeLeft] = useState(10);
  const animatedValue = new Animated.Value(0);
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';

  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      setTimeLeft(10);
      
      const timer = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            setTimeUp();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      
      // Pulse animation
      Animated.loop(
        Animated.sequence([
          Animated.timing(animatedValue, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
            easing: Easing.out(Easing.ease),
          }),
          Animated.timing(animatedValue, {
            toValue: 0,
            duration: 500,
            useNativeDriver: true,
            easing: Easing.in(Easing.ease),
          }),
        ])
      ).start();

      return () => {
        clearInterval(timer);
        animatedValue.stopAnimation();
      };
    }
  }, [gameState]);

  // Animation for pulsing effect
  const pulseScale = animatedValue.interpolate({
    inputRange: [0, 1],
    outputRange: [1, timeLeft <= 3 ? 1.2 : 1.1],
  });

  // Get color based on time left
  const getTimerColor = () => {
    if (timeLeft <= 3) return '#E74C3C';
    if (timeLeft <= 5) return '#F39C12';
    return '#47A025';
  };

  return (
    <View style={styles.container}>
      <Text style={[styles.timeLabel, isDark && styles.timeLabelDark]}>残り時間</Text>
      <Animated.View
        style={[
          styles.timerCircle,
          {
            borderColor: getTimerColor(),
            transform: [{ scale: pulseScale }],
          },
        ]}>
        <Text style={[styles.timerText, { color: getTimerColor() }]}>
          {timeLeft}
        </Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginBottom: 20,
  },
  timeLabel: {
    fontFamily: 'Noto-Sans-JP-Medium',
    fontSize: 16,
    color: '#666',
    marginBottom: 10,
  },
  timeLabelDark: {
    color: '#AAAAAA',
  },
  timerCircle: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 3,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  timerText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 28,
  },
});