import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Animated, useColorScheme } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Gamepad2 } from 'lucide-react-native';

type MatchmakingScreenProps = {
  onFindMatch: () => void;
};

export default function MatchmakingScreen({ onFindMatch }: MatchmakingScreenProps) {
  const [searching, setSearching] = useState(false);
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const colorScheme = useColorScheme();
  const isDark = colorScheme === 'dark';
  
  useEffect(() => {
    if (searching) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.2,
            duration: 700,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 700,
            useNativeDriver: true,
          }),
        ])
      ).start();
      
      // Simulate finding a match after 3 seconds
      const timer = setTimeout(() => {
        setSearching(false);
        onFindMatch();
      }, 3000);
      
      return () => {
        clearTimeout(timer);
        pulseAnim.stopAnimation();
      };
    }
  }, [searching, pulseAnim, onFindMatch]);
  
  const handleStartSearching = () => {
    setSearching(true);
  };

  return (
    <View style={[styles.container, isDark && styles.containerDark]}>
      <Animated.View
        style={[
          styles.iconContainer,
          { transform: [{ scale: searching ? pulseAnim : 1 }] },
        ]}>
        <LinearGradient
          colors={['#5CBF3A', '#47A025']}
          style={styles.iconBackground}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        >
          <Gamepad2 size={60} color="white" />
        </LinearGradient>
      </Animated.View>
      
      <Text style={[styles.title, isDark && styles.titleDark]}>
        {searching ? 'マッチを探しています...' : 'ジャングル・じゃんけん'}
      </Text>
      
      <Text style={[styles.description, isDark && styles.descriptionDark]}>
        {searching 
          ? '他のプレイヤーとマッチングしています。しばらくお待ちください...'
          : 'オンラインで他のプレイヤーと対戦しましょう。グー・チョキ・パーの3つのカードから1枚を選び、相手に勝利しましょう！'}
      </Text>
      
      {!searching && (
        <TouchableOpacity 
          style={styles.button}
          onPress={handleStartSearching}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={['#5CBF3A', '#47A025']}
            style={styles.buttonGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Text style={styles.buttonText}>対戦相手を探す</Text>
          </LinearGradient>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#F9F9F9',
  },
  containerDark: {
    backgroundColor: '#121212',
  },
  iconContainer: {
    marginBottom: 30,
  },
  iconBackground: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#47A025',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 8,
  },
  title: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 24,
    color: '#333333',
    marginBottom: 15,
    textAlign: 'center',
  },
  titleDark: {
    color: '#E0E0E0',
  },
  description: {
    fontFamily: 'Noto-Sans-JP-Regular',
    fontSize: 16,
    color: '#666666',
    textAlign: 'center',
    marginBottom: 40,
    paddingHorizontal: 20,
  },
  descriptionDark: {
    color: '#AAAAAA',
  },
  button: {
    width: '70%',
    borderRadius: 30,
    shadowColor: '#47A025',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  buttonGradient: {
    paddingVertical: 16,
    borderRadius: 30,
    alignItems: 'center',
  },
  buttonText: {
    fontFamily: 'Noto-Sans-JP-Bold',
    fontSize: 18,
    color: 'white',
  },
});