export enum GameState {
  WAITING = 'waiting',
  PLAYING = 'playing',
  RESULT = 'result',
}

export type GameResult = 'win' | 'lose' | 'draw';