import React, { createContext, useState, useContext, ReactNode } from 'react';
import { GameState, GameResult } from '@/types/game';

interface GameContextType {
  gameState: GameState;
  playerChoice: 'rock' | 'paper' | 'scissors' | null;
  opponentChoice: 'rock' | 'paper' | 'scissors' | null;
  result: GameResult | null;
  startGame: () => void;
  endGame: () => void;
  setPlayerChoice: (choice: 'rock' | 'paper' | 'scissors') => void;
  setTimeUp: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const [gameState, setGameState] = useState<GameState>(GameState.WAITING);
  const [playerChoice, setPlayerChoice] = useState<'rock' | 'paper' | 'scissors' | null>(null);
  const [opponentChoice, setOpponentChoice] = useState<'rock' | 'paper' | 'scissors' | null>(null);
  const [result, setResult] = useState<GameResult | null>(null);

  const startGame = () => {
    setGameState(GameState.PLAYING);
    setPlayerChoice(null);
    setOpponentChoice(null);
    setResult(null);
  };

  const endGame = () => {
    setGameState(GameState.WAITING);
    setPlayerChoice(null);
    setOpponentChoice(null);
    setResult(null);
  };

  const determineWinner = (player: 'rock' | 'paper' | 'scissors', opponent: 'rock' | 'paper' | 'scissors'): GameResult => {
    if (player === opponent) return 'draw';
    
    if (
      (player === 'rock' && opponent === 'scissors') ||
      (player === 'paper' && opponent === 'rock') ||
      (player === 'scissors' && opponent === 'paper')
    ) {
      return 'win';
    }
    
    return 'lose';
  };

  const handlePlayerChoice = (choice: 'rock' | 'paper' | 'scissors') => {
    setPlayerChoice(choice);
    
    // Simulate opponent making a choice
    setTimeout(() => {
      const choices: ('rock' | 'paper' | 'scissors')[] = ['rock', 'paper', 'scissors'];
      const randomChoice = choices[Math.floor(Math.random() * choices.length)];
      setOpponentChoice(randomChoice);
      
      setResult(determineWinner(choice, randomChoice));
      setGameState(GameState.RESULT);
    }, Math.random() * 2000 + 1000); // Random time between 1-3 seconds
  };

  const setTimeUp = () => {
    // If player hasn't made a choice, select random
    if (!playerChoice) {
      const choices: ('rock' | 'paper' | 'scissors')[] = ['rock', 'paper', 'scissors'];
      const randomPlayerChoice = choices[Math.floor(Math.random() * choices.length)];
      setPlayerChoice(randomPlayerChoice);
      
      // Simulate opponent making a choice
      const randomOpponentChoice = choices[Math.floor(Math.random() * choices.length)];
      setOpponentChoice(randomOpponentChoice);
      
      setResult(determineWinner(randomPlayerChoice, randomOpponentChoice));
    } else {
      // Player already made a choice, but time is up
      const choices: ('rock' | 'paper' | 'scissors')[] = ['rock', 'paper', 'scissors'];
      const randomOpponentChoice = choices[Math.floor(Math.random() * choices.length)];
      setOpponentChoice(randomOpponentChoice);
      
      setResult(determineWinner(playerChoice, randomOpponentChoice));
    }
    
    setGameState(GameState.RESULT);
  };

  return (
    <GameContext.Provider
      value={{
        gameState,
        playerChoice,
        opponentChoice,
        result,
        startGame,
        endGame,
        setPlayerChoice: handlePlayerChoice,
        setTimeUp,
      }}
    >
      {children}
    </GameContext.Provider>
  );
}

export const useGame = () => {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
};

export { GameContext }